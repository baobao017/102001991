export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>XinhStyle đã lên sóng!</h1>
      <p>Web chạy mượt mà trên Vercel như gió mùa đông bắc.</p>
    </div>
  )
}